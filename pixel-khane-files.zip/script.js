const filterButtons = document.querySelectorAll(".filter");
const gameCards = document.querySelectorAll(".card[data-category]");
const searchInput = document.querySelector("#gameSearch");
const emptyState = document.querySelector("#emptyState");
let activeFilter = "all";

function updateGames() {
  const query = (searchInput?.value || "").trim().toLocaleLowerCase("fa");
  let visible = 0;
  gameCards.forEach(card => {
    const categories = (card.dataset.category || "").split(" ");
    const text = card.innerText.toLocaleLowerCase("fa");
    const matchesCategory = activeFilter === "all" || categories.includes(activeFilter);
    const matchesSearch = !query || text.includes(query);
    const show = matchesCategory && matchesSearch;
    card.hidden = !show;
    if (show) visible++;
  });
  if (emptyState) emptyState.style.display = visible ? "none" : "block";
}

filterButtons.forEach(button => {
  button.addEventListener("click", () => {
    filterButtons.forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    activeFilter = button.dataset.filter || "all";
    updateGames();
  });
});
searchInput?.addEventListener("input", updateGames);
